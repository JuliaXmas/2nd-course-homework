let a = '10';
a = '20';
alert(a);

